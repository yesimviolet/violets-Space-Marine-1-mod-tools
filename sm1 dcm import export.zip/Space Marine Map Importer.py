bl_info = {
    "name":        "Space Marine 1 World Importer",
    "author":      "violet :3",
    "version":     (1, 0),
    "blender":     (5, 0, 1),
    "location":    "File > Import/Export > Space Marine 1 World (.world)",
    "description": "A comprehensive map importer for Warhammer 40,000: Space Marine.",
    "category":    "Space Marine 1",
}

import bpy, struct, os, zlib, math
import xml.dom.minidom
from bpy.props import StringProperty, FloatProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper

# =========================================================================
# ADDON PREFERENCES & WINDOW MANAGER PROPERTIES
# =========================================================================

class SpaceMarineWorldPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    asset_base_path: StringProperty(
        name="Asset Root Folder",
        description="Select the main preview/extracted directory containing your art and package folders.",
        subtype='DIR_PATH',
        default=""
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "asset_base_path")

class IMPORT_OT_sm_world_cancel(bpy.types.Operator):
    bl_idname = "import_scene.sm_world_cancel"
    bl_label = "Cancel Space Marine Import"
    bl_description = "Instantly aborts the current map import queue."
    
    def execute(self, context):
        context.window_manager.sm_cancel_flag = True
        return {'FINISHED'}

class VIEW3D_PT_sm_world_import(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SM Import'
    bl_label = "World Importer Progress"
    
    @classmethod
    def poll(cls, context):
        return context.window_manager.sm_is_importing
        
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        col = layout.column(align=True)
        col.label(text=wm.sm_import_progress, icon='INFO')
        col.separator()
        col.operator("import_scene.sm_world_cancel", text="Cancel Import", icon='CANCEL')

# =========================================================================
# NATIVE BOD PARSER
# =========================================================================

TYPES_MAP = {1: 'object', 2: 'int', 3: 'float', 4: 'bool', 5: '5', 7: 'object', 9: 'array', 11: 'vector', 13: '13', 15: 'hstring', 254: '254', 255: '255'}

class NativeBODParser:
    def __init__(self, filepath, dump_xml=True, out_xml_path=None):
        self.valid = False
        self.filepath = filepath
        if not os.path.exists(filepath): return
        with open(filepath, 'rb') as f: raw = f.read()
        if raw[:3] != b'BOD': return
        
        pos = 5
        compressed = raw[pos]
        pos += 5 
        if compressed:
            size = struct.unpack_from('<I', raw, pos)[0]
            pos += 4
            try:
                self.data = zlib.decompress(raw[pos:])
            except zlib.error:
                try:
                    self.data = zlib.decompress(raw[pos:], -15)
                except Exception as e:
                    print(f"Decompression failed for {filepath}: {e}")
                    return
        else:
            self.data = raw[pos:]
            
        self.pos = 0
        self.strings = {}
        
        if len(self.data) < 8: return
        num_strings = self.r_u32()
        self.r_u32() 
        for _ in range(num_strings):
            if self.pos + 8 > len(self.data): break
            str_id = self.r_bytes(8)
            if self.pos + 4 > len(self.data): break
            strlen = self.r_u32()
            if self.pos + strlen > len(self.data): break
            raw_str = self.r_bytes(strlen)
            self.strings[str_id] = raw_str.decode('utf-8', 'ignore').rstrip('\x00')
        
        self.doc = xml.dom.minidom.Document()
        self.root, root_xml = self.r_object(self.doc, None)
        self.doc.appendChild(root_xml)
        self.valid = True

        if dump_xml:
            if not out_xml_path:
                out_xml_path = filepath + ".xml"
            with open(out_xml_path, 'wt', encoding='utf-8') as f:
                self.doc.writexml(f, addindent='\t', newl='\n', encoding='UTF-8')

    def r_bytes(self, size):
        v = self.data[self.pos : self.pos+size]
        self.pos += size
        return v
    def r_u8(self):
        v = self.data[self.pos]
        self.pos += 1
        return v
    def r_u32(self):
        v = struct.unpack_from('<I', self.data, self.pos)[0]
        self.pos += 4
        return v
    def r_i32(self):
        v = struct.unpack_from('<i', self.data, self.pos)[0]
        self.pos += 4
        return v
    def r_f32(self):
        v = struct.unpack_from('<f', self.data, self.pos)[0]
        self.pos += 4
        return v
    
    def r_object(self, doc, parent=None):
        assert self.r_u8() == 1
        cls_name = self.strings.get(self.r_bytes(8), "")
        count = self.r_u32()
        
        obj_name = 'Element' if parent else 'Object'
        xml_obj = doc.createElement(obj_name)
        xml_obj.setAttribute('Class', cls_name)
        xml_obj.setAttribute('Type', 'object')
        if parent: parent.appendChild(xml_obj)

        dict_obj = {'Class': cls_name, 'Properties': {}}
        for _ in range(count):
            name = self.strings.get(self.r_bytes(8), "")
            prop_dict, prop_xml = self.r_property(doc, xml_obj)
            prop_xml.setAttribute('Name', name)
            xml_obj.appendChild(prop_xml)
            dict_obj['Properties'][name] = prop_dict
            
        return dict_obj, xml_obj

    def r_property(self, doc, parent):
        ptype = self.r_u8()
        prop_xml = None
        if ptype != 7:
            prop_xml = doc.createElement('Property')
            prop_xml.setAttribute('Type', TYPES_MAP.get(ptype, str(ptype)))
            
        dict_val = None
        
        if ptype == 2:
            v = self.r_i32()
            dict_val = v
            prop_xml.setAttribute('Value', str(v))
        elif ptype == 3:
            v = self.r_f32()
            dict_val = v
            prop_xml.setAttribute('Value', str(v))
        elif ptype == 4:
            v = bool(self.r_u8())
            dict_val = v
            prop_xml.setAttribute('Value', str(v).lower())
        elif ptype == 5:
            v = self.strings.get(self.r_bytes(8), "")
            dict_val = v
            prop_xml.setAttribute('Value', v)
        elif ptype == 7:
            obj_id = self.r_u32()
            dict_val, prop_xml = self.r_object(doc, parent)
            prop_xml.setAttribute('ID', str(obj_id))
        elif ptype == 9:
            count = self.r_u32()
            flag = self.r_u8()
            arr_dict = []
            for _ in range(count):
                name = None
                if flag == 1:
                    assert self.r_u8() == 5
                    name = self.strings.get(self.r_bytes(8), "")
                child_dict, child_xml = self.r_property(doc, prop_xml)
                if name:
                    child_xml.setAttribute('Name', name)
                    arr_dict.append((name, child_dict))
                else:
                    arr_dict.append(child_dict)
                prop_xml.appendChild(child_xml)
            dict_val = arr_dict
        elif ptype == 11:
            count = self.r_u32()
            arr_dict = []
            for _ in range(count):
                child_dict, child_xml = self.r_property(doc, prop_xml)
                arr_dict.append(child_dict)
                prop_xml.appendChild(child_xml)
            dict_val = arr_dict
        elif ptype == 13:
            v_bytes = self.r_bytes(8)
            dict_val = v_bytes
            prop_xml.setAttribute('Value', v_bytes.hex())
        elif ptype == 15:
            v = self.strings.get(self.r_bytes(8), "")
            dict_val = v
            prop_xml.setAttribute('Value', v)
        elif ptype == 254:
            dict_val = None
        elif ptype == 255:
            v = self.r_u32()
            dict_val = v
            prop_xml.setAttribute('Value', str(v))
            
        return dict_val, prop_xml

# =========================================================================
# XML PARSING LOGIC
# =========================================================================

def get_property_value(element, prop_name):
    for child in element.childNodes:
        if child.nodeType == child.ELEMENT_NODE and child.tagName == "Property":
            if child.getAttribute("Name") == prop_name:
                return child.getAttribute("Value")
    return None

def get_vector_property(element, prop_name):
    for child in element.childNodes:
        if child.nodeType == child.ELEMENT_NODE and child.tagName == "Property":
            if child.getAttribute("Name") == prop_name and child.getAttribute("Type") == "vector":
                floats = []
                for sub in child.childNodes:
                    if sub.nodeType == sub.ELEMENT_NODE and sub.tagName == "Property":
                        try: floats.append(float(sub.getAttribute("Value")))
                        except ValueError: pass
                if len(floats) >= 3:
                    return floats[:3]
    return None

def get_transform_position(element):
    for child in element.childNodes:
        if child.nodeType == child.ELEMENT_NODE and child.tagName == "Property" and child.getAttribute("Name") in ("Transform", "Matrix"):
            vectors = [c for c in child.childNodes if c.nodeType == c.ELEMENT_NODE and c.tagName == "Property" and c.getAttribute("Type") == "vector"]
            if len(vectors) >= 4:
                floats = []
                for sub in vectors[3].childNodes:
                    if sub.nodeType == sub.ELEMENT_NODE and sub.tagName == "Property":
                        try: floats.append(float(sub.getAttribute("Value")))
                        except ValueError: pass
                if len(floats) >= 3:
                    return floats[:3]
    return None

def find_case_insensitive(base_dir, target_name):
    if not os.path.isdir(base_dir):
        return None
    target_lower = target_name.lower()
    for entry in os.listdir(base_dir):
        if entry.lower() == target_lower:
            return os.path.join(base_dir, entry)
    return None

def create_blender_light(light_data, global_scale):
    light_name = light_data.get("name", "SM_Light")
    light_type = light_data.get("type", 'POINT')
    pos = light_data.get("pos", [0, 0, 0])
    rot = light_data.get("rot", [0, 0, 0])
    color = light_data.get("color", [1, 1, 1])
    power = float(light_data.get("power", 1.0))
    radius = float(light_data.get("radius", 1.0)) 
    
    blender_wattage = power * 100.0 * global_scale
    
    light_data_block = bpy.data.lights.new(name=light_name, type=light_type)
    light_data_block.color = color
    light_data_block.energy = blender_wattage
    
    if light_type == 'SPOT':
        fov = float(light_data.get("fov", 45.0))
        light_data_block.spot_size = math.radians(fov)
        light_data_block.spot_blend = 0.5
        
    light_data_block.cutoff_distance = radius * global_scale
    
    light_obj = bpy.data.objects.new(name=light_name, object_data=light_data_block)
    
    light_obj.location = (pos[0] * global_scale, pos[1] * global_scale, -pos[2] * global_scale)
    light_obj.rotation_euler = (math.radians(rot[0]), math.radians(rot[1]), math.radians(-rot[2]))
    
    scene_collection = bpy.context.scene.collection
    lights_coll = bpy.data.collections.get("Lights")
    if not lights_coll:
        lights_coll = bpy.data.collections.new("Lights")
        scene_collection.children.link(lights_coll)
        
    lights_coll.objects.link(light_obj)

# =========================================================================
# MAIN IMPORTER OPERATOR
# =========================================================================

class IMPORT_OT_space_marine_world(bpy.types.Operator, ImportHelper):
    bl_idname    = "import_scene.space_marine_world"
    bl_label     = "Import Space Marine World"
    filename_ext = ".world"
    filter_glob: StringProperty(default="*.world", options={'HIDDEN'})
    
    global_scale: FloatProperty(name="Scale", default=1.0, min=0.001, max=1000.0)
    import_skeletons: BoolProperty(name="Import Skeletons", default=False, description="Map props usually do not need Armatures.")

    def queue_file_for_decompilation(self, filepath):
        if filepath and os.path.exists(filepath) and filepath not in self.processed_files:
            self.processed_files.add(filepath)
            xml_path = filepath + ".xml"
            
            if os.path.exists(xml_path):
                if filepath.lower().endswith(".world"):
                    self.task_queue.append(("UI_UPDATE", f"Reading World:\n{os.path.basename(xml_path)}"))
                    self.task_queue.append(("PARSE_WORLD", xml_path))
                elif filepath.lower().endswith(".region"):
                    self.task_queue.append(("UI_UPDATE", f"Reading Region:\n{os.path.basename(xml_path)}"))
                    self.task_queue.append(("PARSE_REGION", xml_path))
                elif filepath.lower().endswith(".layer"):
                    self.task_queue.append(("UI_UPDATE", f"Reading Layer:\n{os.path.basename(xml_path)}"))
                    self.task_queue.append(("PARSE_LAYER", xml_path))
            else:
                self.task_queue.append(("UI_UPDATE", f"Decompiling:\n{os.path.basename(filepath)}"))
                self.task_queue.append(("DECOMPILE", filepath))

    def modal(self, context, event):
        if event.type == 'ESC':
            self.clean_up(context)
            self.report({'WARNING'}, "Map import cancelled by user (ESC).")
            return {'CANCELLED'}

        if context.window_manager.sm_cancel_flag:
            self.clean_up(context)
            self.report({'WARNING'}, "Map import cancelled via UI button.")
            return {'CANCELLED'}

        if event.type == 'TIMER':
            # --- PENDING HEAVY IMPORT BLOCK ---
            if hasattr(self, 'pending_import_item') and self.pending_import_item:
                item = self.pending_import_item
                self.pending_import_item = None
                
                if item.get("is_light"):
                    create_blender_light(item, self.global_scale)
                    return {'PASS_THROUGH'}

                dcm_path = item["dcm_path"]
                pos = item["pos"]
                rot = item["rot"]
                scl = item["scl"]
                pkg_name = item["pkg_name"]
                obj_name = item["obj_name"]

                existing_objs = set(context.scene.objects)
                
                try:
                    bpy.ops.import_scene.space_marine_dcm(
                        filepath=dcm_path, 
                        global_scale=self.global_scale,
                        import_skeleton=self.import_skeletons,
                        use_custom_shader=True
                    )
                except Exception as e:
                    print(f"World Importer: Execution failed on {dcm_path}: {e}")
                    return {'PASS_THROUGH'}
                    
                new_objs = set(context.scene.objects) - existing_objs
                
                pkg_coll = bpy.data.collections.get(pkg_name)
                if not pkg_coll:
                    pkg_coll = bpy.data.collections.new(pkg_name)
                    context.scene.collection.children.link(pkg_coll)
                    
                obj_coll = bpy.data.collections.get(obj_name)
                if not obj_coll:
                    obj_coll = bpy.data.collections.new(obj_name)
                    pkg_coll.children.link(obj_coll)

                root_objs = [o for o in new_objs if o.parent is None]
                
                for root_obj in root_objs:
                    root_obj.location = (pos[0] * self.global_scale, pos[1] * self.global_scale, -pos[2] * self.global_scale)
                    root_obj.rotation_euler = (math.radians(rot[0]), math.radians(rot[1]), math.radians(-rot[2]))
                    root_obj.scale = (scl[0], scl[1], scl[2])
                    
                for obj in new_objs:
                    for col in obj.users_collection:
                        col.objects.unlink(obj)
                    if obj.name not in obj_coll.objects:
                        obj_coll.objects.link(obj)

                return {'PASS_THROUGH'}


            # --- PHASE 1: ASYNC DECOMPILING AND PARSING ---
            if self.phase == "PARSING":
                if self.task_queue:
                    task_type, payload = self.task_queue.pop(0)
                    
                    if task_type == "UI_UPDATE":
                        context.window_manager.sm_import_progress = payload
                        context.workspace.status_text_set(payload.replace('\n', ' '))
                        return {'PASS_THROUGH'}
                        
                    elif task_type == "DECOMPILE":
                        filepath = payload
                        parser = NativeBODParser(filepath, dump_xml=True)
                        if parser.valid:
                            xml_path = filepath + ".xml"
                            if filepath.lower().endswith(".world"):
                                self.task_queue.insert(0, ("PARSE_WORLD", xml_path))
                                self.task_queue.insert(0, ("UI_UPDATE", f"Reading World:\n{os.path.basename(xml_path)}"))
                            elif filepath.lower().endswith(".region"):
                                self.task_queue.insert(0, ("PARSE_REGION", xml_path))
                                self.task_queue.insert(0, ("UI_UPDATE", f"Reading Region:\n{os.path.basename(xml_path)}"))
                            elif filepath.lower().endswith(".layer"):
                                self.task_queue.insert(0, ("PARSE_LAYER", xml_path))
                                self.task_queue.insert(0, ("UI_UPDATE", f"Reading Layer:\n{os.path.basename(xml_path)}"))
                                
                    elif task_type == "PARSE_WORLD":
                        xml_path = payload
                        try:
                            doc = xml.dom.minidom.parse(xml_path)
                            for el in doc.getElementsByTagName("Element"):
                                if el.getAttribute("Class") == "WorldRegionData":
                                    rname = get_property_value(el, "Name")
                                    if rname:
                                        region_dir = find_case_insensitive(self.map_dir, rname)
                                        if region_dir and os.path.isdir(region_dir):
                                            region_file = find_case_insensitive(region_dir, rname + ".region")
                                            self.queue_file_for_decompilation(region_file)
                        except Exception as e:
                            print(f"Error parsing {xml_path}: {e}")
                            
                    elif task_type == "PARSE_REGION":
                        xml_path = payload
                        try:
                            doc = xml.dom.minidom.parse(xml_path)
                            region_dir = os.path.dirname(xml_path)
                            for el in doc.getElementsByTagName("Element"):
                                if el.getAttribute("Class") == "RegionLayerData":
                                    lname = get_property_value(el, "Name")
                                    if lname:
                                        layer_file = find_case_insensitive(region_dir, lname + ".layer")
                                        self.queue_file_for_decompilation(layer_file)
                        except Exception as e:
                            print(f"Error parsing {xml_path}: {e}")
                            
                    elif task_type == "PARSE_LAYER":
                        xml_path = payload
                        try:
                            doc = xml.dom.minidom.parse(xml_path)
                            for el in doc.getElementsByTagName("Element"):
                                el_class = el.getAttribute("Class").lower()
                                
                                # Lights
                                if el_class in ("base/omnilight", "base/spotlight"):
                                    light_name = get_property_value(el, "Name") or "SM_Light"
                                    pos = get_vector_property(el, "Position") or [0,0,0]
                                    rot = get_vector_property(el, "Rotation") or [0,0,0]
                                    color = get_vector_property(el, "Color") or [1,1,1]
                                    
                                    power = 1.0
                                    fov = 45.0
                                    atten_end = 1.0
                                    
                                    for p in el.childNodes:
                                        if p.nodeType == p.ELEMENT_NODE and p.tagName == "Property":
                                            pname = p.getAttribute("Name")
                                            if pname == "Power": power = p.getAttribute("Value")
                                            elif pname == "FOV": fov = p.getAttribute("Value")
                                            elif pname == "AttenEnd": atten_end = p.getAttribute("Value")

                                    self.import_queue.append({
                                        "is_light": True,
                                        "type": 'SPOT' if el_class == "base/spotlight" else 'POINT',
                                        "name": light_name,
                                        "pos": pos,
                                        "rot": rot,
                                        "color": color,
                                        "power": power,
                                        "fov": fov,
                                        "radius": atten_end
                                    })
                                    continue

                                # Meshes
                                obj_name = (get_property_value(el, "ObjectName") or 
                                            get_property_value(el, "MeshName") or 
                                            get_property_value(el, "Model") or 
                                            get_property_value(el, "Blueprint") or 
                                            get_property_value(el, "Visual") or
                                            get_property_value(el, "Reference") or
                                            get_property_value(el, "Name"))
                                            
                                pkg_name = get_property_value(el, "PackageName")
                                pos = get_vector_property(el, "Position") or get_transform_position(el)
                                
                                if not obj_name or not pos:
                                    continue 
                                    
                                rot = get_vector_property(el, "Rotation") or [0.0, 0.0, 0.0]
                                scl = get_vector_property(el, "Scale") or [1.0, 1.0, 1.0]
                                
                                dcm_filename = obj_name + ".dcm"
                                dcm_path = None
                                
                                if pkg_name:
                                    target_key = f"{pkg_name.lower()}/{obj_name.lower()}"
                                    if target_key in self.dcm_cache:
                                        dcm_path = self.dcm_cache[target_key]
                                        
                                if not dcm_path and obj_name.lower() in self.dcm_fallback:
                                    dcm_path = self.dcm_fallback[obj_name.lower()]

                                if not dcm_path:
                                    if pkg_name:
                                        p1 = find_case_insensitive(self.map_dir, pkg_name)
                                        if p1 and os.path.isdir(p1):
                                            dcm_path = find_case_insensitive(p1, dcm_filename)
                                    if not dcm_path:
                                        dcm_path = find_case_insensitive(self.map_dir, dcm_filename)
                                                
                                if not dcm_path:
                                    print(f"World Importer [SKIPPED]: Missing asset '{dcm_filename}' (Package: {pkg_name})")
                                    self.missing_count += 1
                                    continue
                                
                                self.import_queue.append({
                                    "is_light": False,
                                    "dcm_path": dcm_path,
                                    "pos": pos,
                                    "rot": rot,
                                    "scl": scl,
                                    "pkg_name": pkg_name or "Unknown_Package",
                                    "obj_name": obj_name or "Unknown_Object"
                                })
                        except Exception as e:
                            print(f"Error parsing {xml_path}: {e}")
                            
                    return {'PASS_THROUGH'}
                else:
                    self.phase = "IMPORTING"
                    self.total_items = len(self.import_queue)
                    self.current_item = 0
                    
                    if self.total_items == 0:
                        self.clean_up(context)
                        self.report({'WARNING'}, f"No valid mesh/light entries found to import. Missing {self.missing_count} assets.")
                        return {'CANCELLED'}
                        
                    context.window_manager.progress_begin(0, self.total_items)
                    return {'PASS_THROUGH'}

            # --- PHASE 2: ASYNC IMPORTING ---
            elif self.phase == "IMPORTING":
                if not self.import_queue:
                    self.clean_up(context)
                    self.report({'INFO'}, f"World import complete! Generated {self.total_items} items.")
                    return {'FINISHED'}

                item = self.import_queue.pop(0)
                self.current_item += 1
                
                if item.get("is_light"):
                    context.window_manager.sm_import_progress = f"Importing: {self.current_item} / {self.total_items}\nLight: {item['name']}"
                else:
                    context.window_manager.sm_import_progress = f"Importing: {self.current_item} / {self.total_items}\nMesh: {os.path.basename(item['dcm_path'])}"
                    
                context.window_manager.progress_update(self.current_item)
                
                self.pending_import_item = item
                return {'PASS_THROUGH'}

        return {'PASS_THROUGH'}
        
    def clean_up(self, context):
        if hasattr(self, '_timer') and self._timer:
            context.window_manager.event_timer_remove(self._timer)
        context.window_manager.progress_end()
        context.workspace.status_text_set(None)
        context.window_manager.sm_is_importing = False
        context.window_manager.sm_cancel_flag = False
        context.window_manager.sm_import_progress = ""

    def execute(self, context):
        if not hasattr(bpy.ops.import_scene, "space_marine_dcm"):
            self.report({'ERROR'}, "Base Space Marine DCM Importer is not installed or enabled.")
            return {'CANCELLED'}

        prefs = context.preferences.addons.get(__name__)
        asset_base_path = prefs.preferences.asset_base_path if prefs else ""

        self.map_dir = os.path.dirname(self.filepath)
        self.dcm_cache = {}        
        self.dcm_fallback = {}     
        self.import_queue = []
        self.task_queue = []
        self.processed_files = set()
        self.missing_count = 0
        self.phase = "PARSING"
        self.pending_import_item = None

        if asset_base_path and os.path.exists(bpy.path.abspath(asset_base_path)):
            base_path = bpy.path.abspath(asset_base_path)
            self.report({'INFO'}, f"Indexing assets in {base_path}...")
            
            for root, dirs, files in os.walk(base_path):
                pkg_folder = os.path.basename(root).lower()
                for f in files:
                    if f.lower().endswith('.dcm'):
                        obj_name = f[:-4].lower()
                        full_path = os.path.join(root, f)
                        cache_key = f"{pkg_folder}/{obj_name}"
                        
                        if cache_key not in self.dcm_cache or 'art' in root.lower().split(os.sep):
                            self.dcm_cache[cache_key] = full_path
                        if obj_name not in self.dcm_fallback or 'art' in root.lower().split(os.sep):
                            self.dcm_fallback[obj_name] = full_path

        self.queue_file_for_decompilation(self.filepath)
        
        for f in os.listdir(self.map_dir):
            if f.lower().endswith(".layer"):
                self.queue_file_for_decompilation(os.path.join(self.map_dir, f))

        context.window_manager.sm_is_importing = True
        context.window_manager.sm_cancel_flag = False
        context.window_manager.sm_import_progress = "Initializing Data Queues..."
        
        self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
        context.window_manager.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}

def menu_import_world(self, context):
    self.layout.operator(IMPORT_OT_space_marine_world.bl_idname, text="Space Marine World (.world)")

def register():
    bpy.types.WindowManager.sm_import_progress = StringProperty(default="")
    bpy.types.WindowManager.sm_cancel_flag = BoolProperty(default=False)
    bpy.types.WindowManager.sm_is_importing = BoolProperty(default=False)

    bpy.utils.register_class(SpaceMarineWorldPreferences)
    bpy.utils.register_class(IMPORT_OT_sm_world_cancel)
    bpy.utils.register_class(VIEW3D_PT_sm_world_import)
    bpy.utils.register_class(IMPORT_OT_space_marine_world)
    bpy.types.TOPBAR_MT_file_import.append(menu_import_world)

def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import_world)
    bpy.utils.unregister_class(IMPORT_OT_space_marine_world)
    bpy.utils.unregister_class(VIEW3D_PT_sm_world_import)
    bpy.utils.unregister_class(IMPORT_OT_sm_world_cancel)
    bpy.utils.unregister_class(SpaceMarineWorldPreferences)

    del bpy.types.WindowManager.sm_import_progress
    del bpy.types.WindowManager.sm_cancel_flag
    del bpy.types.WindowManager.sm_is_importing

if __name__ == "__main__":
    register()