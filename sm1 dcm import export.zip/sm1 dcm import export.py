bl_info = {
    "name":        "Space Marine DCM Importer/Exporter",
    "author":      "Violet :3",
    "version":     (6, 6),
    "blender":     (5, 0, 1),
    "location":    "File > Import/Export > Space Marine DCM (.dcm)",
    "description": "Import/Export DCM models. API-compliant UV seam splitting and vertex duplication.",
    "category":    "Import-Export",
}

import bpy, struct, os, mathutils, zlib, math
import xml.dom.minidom
from bpy.props import StringProperty, BoolProperty, FloatProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper
import bmesh

# =========================================================================
# FLOAT SANITIZER
# =========================================================================
def _sf(v):
    return 0.0 if math.isnan(v) or math.isinf(v) else v

# =========================================================================
# NATIVE BOD PARSER & COMPILER 
# =========================================================================

S_HASH_DATA = [
    0x0, 0x0, 0x5800C, 0x1A1561E, 0x0B0018, 0x342AC3C, 0x0E8014, 0x2E3FA22, 0x160030, 0x6855878, 0x13803C, 0x7240E66, 0x1D0028, 0x5C7F444, 0x188024, 0x466A25A,
    0x2C0060, 0x0D0AB0F0, 0x29806C, 0x0CABE6EE, 0x270078, 0x0E481CCC, 0x228074, 0x0FE94AD2, 0x3A0050, 0x0B8FE888, 0x3F805C, 0x0A2EBE96, 0x310048, 0x8CD44B4, 0x348044, 0x96C12AA,
    0x5800C0, 0x1A1561E0, 0x5D80CC, 0x1BB437FE, 0x5300D8, 0x1957CDDC, 0x5680D4, 0x18F69BC2, 0x4E00F0, 0x1C903998, 0x4B80FC, 0x1D316F86, 0x4500E8, 0x1FD295A4, 0x4080E4, 0x1E73C3BA,
    0x7400A0, 0x171FD110, 0x7180AC, 0x16BE870E, 0x7F00B8, 0x145D7D2C, 0x7A80B4, 0x15FC2B32, 0x620090, 0x119A8968, 0x67809C, 0x103BDF76, 0x690088, 0x12D82554, 0x6C8084, 0x1379734A,
    0x0B00180, 0x342AC3C0, 0x0B5818C, 0x358B95DE, 0x0BB0198, 0x37686FFC, 0x0BE8194, 0x36C939E2, 0x0A601B0, 0x32AF9BB8, 0x0A381BC, 0x330ECDA6, 0x0AD01A8, 0x31ED3784, 0x0A881A4, 0x304C619A,
    0x9C01E0, 0x39207330, 0x9981EC, 0x3881252E, 0x9701F8, 0x3A62DF0C, 0x9281F4, 0x3BC38912, 0x8A01D0, 0x3FA52B48, 0x8F81DC, 0x3E047D56, 0x8101C8, 0x3CE78774, 0x8481C4, 0x3D46D16A,
    0x0E80140, 0x2E3FA220, 0x0ED814C, 0x2F9EF43E, 0x0E30158, 0x2D7D0E1C, 0x0E68154, 0x2CDC5802, 0x0FE0170, 0x28BAFA58, 0x0FB817C, 0x291BAC46, 0x0F50168, 0x2BF85664, 0x0F08164, 0x2A59007A,
    0x0C40120, 0x233512D0, 0x0C1812C, 0x229444CE, 0x0CF0138, 0x2077BEEC, 0x0CA8134, 0x21D6E8F2, 0x0D20110, 0x25B04AA8, 0x0D7811C, 0x24111CB6, 0x0D90108, 0x26F2E694, 0x0DC8104, 0x2753B08A,
    0x1600300, 0x68558780, 0x165830C, 0x69F4D19E, 0x16B0318, 0x6B172BBC, 0x16E8314, 0x6AB67DA2, 0x1760330, 0x6ED0DFF8, 0x173833C, 0x6F7189E6, 0x17D0328, 0x6D9273C4, 0x1788324, 0x6C3325DA,
    0x14C0360, 0x655F3770, 0x149836C, 0x64FE616E, 0x1470378, 0x661D9B4C, 0x1428374, 0x67BCCD52, 0x15A0350, 0x63DA6F08, 0x15F835C, 0x627B3916, 0x1510348, 0x6098C334, 0x1548344, 0x6139952A,
    0x13803C0, 0x7240E660, 0x13D83CC, 0x73E1B07E, 0x13303D8, 0x71024A5C, 0x13683D4, 0x70A31C42, 0x12E03F0, 0x74C5BE18, 0x12B83FC, 0x7564E806, 0x12503E8, 0x77871224, 0x12083E4, 0x7626443A,
    0x11403A0, 0x7F4A5690, 0x11183AC, 0x7EEB008E, 0x11F03B8, 0x7C08FAAC, 0x11A83B4, 0x7DA9ACB2, 0x1020390, 0x79CF0EE8, 0x107839C, 0x786E58F6, 0x1090388, 0x7A8DA2D4, 0x10C8384, 0x7B2CF4CA,
    0x1D00280, 0x5C7F4440, 0x1D5828C, 0x5DDE125E, 0x1DB0298, 0x5F3DE87C, 0x1DE8294, 0x5E9CBE62, 0x1C602B0, 0x5AFA1C38, 0x1C382BC, 0x5B5B4A26, 0x1CD02A8, 0x59B8B004, 0x1C882A4, 0x5819E61A,
    0x1FC02E0, 0x5175F4B0, 0x1F982EC, 0x50D4A2AE, 0x1F702F8, 0x5237588C, 0x1F282F4, 0x53960E92, 0x1EA02D0, 0x57F0ACC8, 0x1EF82DC, 0x5651FAD6, 0x1E102C8, 0x54B200F4, 0x1E482C4, 0x551356EA,
    0x1880240, 0x466A25A0, 0x18D824C, 0x47CB73BE, 0x1830258, 0x4528899C, 0x1868254, 0x4489DF82, 0x19E0270, 0x40EF7DD8, 0x19B827C, 0x414E2BC6, 0x1950268, 0x43ADD1E4, 0x1908264, 0x420C87FA,
    0x1A40220, 0x4B609550, 0x1A1822C, 0x4AC1C34E, 0x1AF0238, 0x4822396C, 0x1AA8234, 0x49836F72, 0x1B20210, 0x4DE5CD28, 0x1B7821C, 0x4C449B36, 0x1B90208, 0x4EA76114, 0x1BC8204, 0x4F06370A,
    0x2C00600, 0x0D0AB0F00, 0x2C5860C, 0x0D10A591E, 0x2CB0618, 0x0D3E9A33C, 0x2CE8614, 0x0D248F522, 0x2D60630, 0x0D62E5778, 0x2D3863C, 0x0D78F0166, 0x2DD0628, 0x0D56CFB44, 0x2D88624, 0x0D4CDAD5A,
    0x2EC0660, 0x0DDA1BFF0, 0x2E9866C, 0x0DC00E9EE, 0x2E70678, 0x0DEE313CC, 0x2E28674, 0x0DF4245D2, 0x2FA0650, 0x0DB24E788, 0x2FF865C, 0x0DA85B196, 0x2F10648, 0x0D8664BB4, 0x2F48644, 0x0D9C71DAA,
    0x29806C0, 0x0CABE6EE0, 0x29D86CC, 0x0CB1F38FE, 0x29306D8, 0x0C9FCC2DC, 0x29686D4, 0x0C85D94C2, 0x28E06F0, 0x0CC3B3698, 0x28B86FC, 0x0CD9A6086, 0x28506E8, 0x0CF799AA4, 0x28086E4, 0x0CED8CCBA,
    0x2B406A0, 0x0C7B4DE10, 0x2B186AC, 0x0C615880E, 0x2BF06B8, 0x0C4F6722C, 0x2BA86B4, 0x0C5572432, 0x2A20690, 0x0C1318668, 0x2A7869C, 0x0C090D076, 0x2A90688, 0x0C2732A54, 0x2AC8684, 0x0C3D27C4A,
    0x2700780, 0x0E481CCC0, 0x275878C, 0x0E5209ADE, 0x27B0798, 0x0E7C360FC, 0x27E8794, 0x0E66236E2, 0x26607B0, 0x0E20494B8, 0x26387BC, 0x0E3A5C2A6, 0x26D07A8, 0x0E1463884, 0x26887A4, 0x0E0E76E9A,
    0x25C07E0, 0x0E98B7C30, 0x25987EC, 0x0E82A2A2E, 0x25707F8, 0x0EAC9D00C, 0x25287F4, 0x0EB688612, 0x24A07D0, 0x0EF0E2448, 0x24F87DC, 0x0EEAF7256, 0x24107C8, 0x0EC4C8874, 0x24487C4, 0x0EDEDDE6A,
    0x2280740, 0x0FE94AD20, 0x22D874C, 0x0FF35FB3E, 0x2230758, 0x0FDD6011C, 0x2268754, 0x0FC775702, 0x23E0770, 0x0F811F558, 0x23B877C, 0x0F9B0A346, 0x2350768, 0x0FB535964, 0x2308764, 0x0FAF20F7A,
    0x2040720, 0x0F39E1DD0, 0x201872C, 0x0F23F4BCE, 0x20F0738, 0x0F0DCB1EC, 0x20A8734, 0x0F17DE7F2, 0x2120710, 0x0F51B45A8, 0x217871C, 0x0F4BA13B6, 0x2190708, 0x0F659E994, 0x21C8704, 0x0F7F8BF8A,
    0x3A00500, 0x0B8FE8880, 0x3A5850C, 0x0B95FDE9E, 0x3AB0518, 0x0BBBC24BC, 0x3AE8514, 0x0BA1D72A2, 0x3B60530, 0x0BE7BD0F8, 0x3B3853C, 0x0BFDA86E6, 0x3BD0528, 0x0BD397CC4, 0x3B88524, 0x0BC982ADA,
    0x38C0560, 0x0B5F43870, 0x389856C, 0x0B4556E6E, 0x3870578, 0x0B6B6944C, 0x3828574, 0x0B717C252, 0x39A0550, 0x0B3716008, 0x39F855C, 0x0B2D03616, 0x3910548, 0x0B033CC34, 0x3948544, 0x0B1929A2A,
    0x3F805C0, 0x0A2EBE960, 0x3FD85CC, 0x0A34ABF7E, 0x3F305D8, 0x0A1A9455C, 0x3F685D4, 0x0A0081342, 0x3EE05F0, 0x0A46EB118, 0x3EB85FC, 0x0A5CFE706, 0x3E505E8, 0x0A72C1D24, 0x3E085E4, 0x0A68D4B3A,
    0x3D405A0, 0x0AFE15990, 0x3D185AC, 0x0AE400F8E, 0x3DF05B8, 0x0ACA3F5AC, 0x3DA85B4, 0x0AD02A3B2, 0x3C20590, 0x0A96401E8, 0x3C7859C, 0x0A8C557F6, 0x3C90588, 0x0AA26ADD4, 0x3CC8584, 0x0AB87FBCA,
    0x3100480, 0x8CD44B40, 0x315848C, 0x8D751D5E, 0x31B0498, 0x8F96E77C, 0x31E8494, 0x8E37B162, 0x30604B0, 0x8A511338, 0x30384BC, 0x8BF04526, 0x30D04A8, 0x8913BF04, 0x30884A4, 0x88B2E91A,
    0x33C04E0, 0x81DEFBB0, 0x33984EC, 0x807FADAE, 0x33704F8, 0x829C578C, 0x33284F4, 0x833D0192, 0x32A04D0, 0x875BA3C8, 0x32F84DC, 0x86FAF5D6, 0x32104C8, 0x84190FF4, 0x32484C4, 0x85B859EA,
    0x3480440, 0x96C12AA0, 0x34D844C, 0x97607CBE, 0x3430458, 0x9583869C, 0x3468454, 0x9422D082, 0x35E0470, 0x904472D8, 0x35B847C, 0x91E524C6, 0x3550468, 0x9306DEE4, 0x3508464, 0x92A788FA,
    0x3640420, 0x9BCB9A50, 0x361842C, 0x9A6ACC4E, 0x36F0438, 0x9889366C, 0x36A8434, 0x99286072, 0x3720410, 0x9D4EC228, 0x377841C, 0x9CEF9436, 0x3790408, 0x9E0C6E14, 0x37C8404, 0x9FAD380A
]

TYPES_MAP = {1: 'object', 2: 'int', 3: 'float', 4: 'bool', 5: '5', 7: 'object', 9: 'array', 11: 'vector', 13: '13', 15: 'hstring', 254: '254', 255: '255'}

def get_sm_hash(text):
    to_hash = text.encode('utf-8')
    f_part = 0xFFFFFFFF
    s_part = 0xFFFFFFFF
    for current in to_hash:
        offset = (current ^ f_part) & 0xFF
        f_part = f_part >> 8
        s_part_last = (s_part & 0xFF) << 24
        f_part = f_part | s_part_last
        s_part = s_part >> 8
        f_part = f_part ^ S_HASH_DATA[offset * 2]
        s_part = s_part ^ S_HASH_DATA[(offset * 2) + 1]
    first_32 = (~f_part) & 0xFFFFFFFF
    second_32 = (~s_part) & 0xFFFFFFFF
    return struct.pack("<II", first_32, second_32)

class NativeBODParser:
    def __init__(self, filepath, dump_xml=True, out_xml_path=None):
        self.valid = False
        self.filepath = filepath
        if not os.path.exists(filepath): return
        with open(filepath, 'rb') as f: raw = f.read()
        if raw[:3] != b'BOD': return
        
        pos = 5
        compressed = raw[pos]
        pos += 5 
        if compressed:
            size = struct.unpack_from('<I', raw, pos)[0]
            pos += 4
            try:
                self.data = zlib.decompress(raw[pos:])
            except zlib.error:
                try:
                    self.data = zlib.decompress(raw[pos:], -15)
                except Exception as e:
                    raise RuntimeError(f"Decompression failed for {filepath}: {e}")
        else:
            self.data = raw[pos:]
            
        self.pos = 0
        self.strings = {}
        
        if len(self.data) < 8: return
        num_strings = self.r_u32()
        self.r_u32() 
        for _ in range(num_strings):
            if self.pos + 8 > len(self.data): break
            str_id = self.r_bytes(8)
            if self.pos + 4 > len(self.data): break
            strlen = self.r_u32()
            if self.pos + strlen > len(self.data): break
            self.strings[str_id] = self.r_bytes(strlen).decode('utf-8', 'ignore')
        
        self.doc = xml.dom.minidom.Document()
        self.root, root_xml = self.r_object(self.doc, None)
        self.doc.appendChild(root_xml)
        self.valid = True

        if dump_xml:
            if not out_xml_path:
                out_xml_path = filepath + ".xml"
            with open(out_xml_path, 'wt', encoding='utf-8') as f:
                self.doc.writexml(f, addindent='\t', newl='\n', encoding='UTF-8')

    def r_bytes(self, size):
        v = self.data[self.pos : self.pos+size]
        self.pos += size
        return v
    def r_u8(self):
        v = self.data[self.pos]
        self.pos += 1
        return v
    def r_u32(self):
        v = struct.unpack_from('<I', self.data, self.pos)[0]
        self.pos += 4
        return v
    def r_i32(self):
        v = struct.unpack_from('<i', self.data, self.pos)[0]
        self.pos += 4
        return v
    def r_f32(self):
        v = struct.unpack_from('<f', self.data, self.pos)[0]
        self.pos += 4
        return v
    
    def r_object(self, doc, parent=None):
        assert self.r_u8() == 1
        cls_name = self.strings[self.r_bytes(8)]
        count = self.r_u32()
        
        obj_name = 'Element' if parent else 'Object'
        xml_obj = doc.createElement(obj_name)
        xml_obj.setAttribute('Class', cls_name)
        xml_obj.setAttribute('Type', 'object')
        if parent: parent.appendChild(xml_obj)

        dict_obj = {'Class': cls_name, 'Properties': {}}
        for _ in range(count):
            name = self.strings[self.r_bytes(8)]
            prop_dict, prop_xml = self.r_property(doc, xml_obj)
            prop_xml.setAttribute('Name', name)
            xml_obj.appendChild(prop_xml)
            dict_obj['Properties'][name] = prop_dict
            
        return dict_obj, xml_obj

    def r_property(self, doc, parent):
        ptype = self.r_u8()
        prop_xml = None
        if ptype != 7:
            prop_xml = doc.createElement('Property')
            prop_xml.setAttribute('Type', TYPES_MAP.get(ptype, str(ptype)))
            
        dict_val = None
        
        if ptype == 2:
            v = self.r_i32()
            dict_val = v
            prop_xml.setAttribute('Value', str(v))
        elif ptype == 3:
            v = self.r_f32()
            dict_val = v
            prop_xml.setAttribute('Value', str(v))
        elif ptype == 4:
            v = bool(self.r_u8())
            dict_val = v
            prop_xml.setAttribute('Value', str(v).lower())
        elif ptype == 5:
            v = self.strings[self.r_bytes(8)]
            dict_val = v
            prop_xml.setAttribute('Value', v)
        elif ptype == 7:
            obj_id = self.r_u32()
            dict_val, prop_xml = self.r_object(doc, parent)
            prop_xml.setAttribute('ID', str(obj_id))
        elif ptype == 9:
            count = self.r_u32()
            flag = self.r_u8()
            arr_dict = []
            for _ in range(count):
                name = None
                if flag == 1:
                    assert self.r_u8() == 5
                    name = self.strings[self.r_bytes(8)]
                child_dict, child_xml = self.r_property(doc, prop_xml)
                if name:
                    child_xml.setAttribute('Name', name)
                    arr_dict.append((name, child_dict))
                else:
                    arr_dict.append(child_dict)
                prop_xml.appendChild(child_xml)
            dict_val = arr_dict
        elif ptype == 11:
            count = self.r_u32()
            arr_dict = []
            for _ in range(count):
                child_dict, child_xml = self.r_property(doc, prop_xml)
                arr_dict.append(child_dict)
                prop_xml.appendChild(child_xml)
            dict_val = arr_dict
        elif ptype == 13:
            v_bytes = self.r_bytes(8)
            dict_val = v_bytes
            prop_xml.setAttribute('Value', v_bytes.hex())
        elif ptype == 15:
            v = self.strings[self.r_bytes(8)]
            dict_val = v
            prop_xml.setAttribute('Value', v)
        elif ptype == 254:
            dict_val = None
        elif ptype == 255:
            v = self.r_u32()
            dict_val = v
            prop_xml.setAttribute('Value', str(v))
            
        return dict_val, prop_xml

def compile_bod_from_xml(xml_path, out_path):
    if not os.path.exists(xml_path): return False
    try:
        doc = xml.dom.minidom.parse(xml_path)
        strings = {}
        string_list = []

        def add_str(s):
            if s and s not in strings:
                strings[s] = get_sm_hash(s)
                string_list.append(s)

        def gather_strings(node):
            if node.nodeType == node.ELEMENT_NODE:
                if node.tagName in ('Object', 'Element'):
                    add_str(node.getAttribute('Class'))
                if node.hasAttribute('Name'):
                    add_str(node.getAttribute('Name'))
                if node.getAttribute('Type') in ('5', 'hstring'):
                    add_str(node.getAttribute('Value'))
            for child in node.childNodes:
                gather_strings(child)

        gather_strings(doc.documentElement)

        data = bytearray()
        def w_u8(v): data.extend(struct.pack('<B', v))
        def w_u32(v): data.extend(struct.pack('<I', v))
        def w_i32(v): data.extend(struct.pack('<i', v))
        def w_f32(v): data.extend(struct.pack('<f', v))
        def w_bytes(b): data.extend(b)

        def w_property(node):
            if node.tagName in ('Object', 'Element'):
                w_u8(7)
                w_u32(int(node.getAttribute('ID')))
                w_object(node)
                return

            t_str = node.getAttribute('Type')
            ptype = {'int': 2, 'float': 3, 'bool': 4, '5': 5, 'array': 9, 'vector': 11, '13': 13, 'hstring': 15, '254': 254, '255': 255}.get(t_str, 254)
            w_u8(ptype)

            if ptype == 2: w_i32(int(node.getAttribute('Value')))
            elif ptype == 3: w_f32(float(node.getAttribute('Value')))
            elif ptype == 4: w_u8(1 if node.getAttribute('Value').lower() == 'true' else 0)
            elif ptype == 5: w_bytes(strings[node.getAttribute('Value')])
            elif ptype == 9:
                children = [c for c in node.childNodes if c.nodeType == c.ELEMENT_NODE]
                w_u32(len(children))
                flag = 1 if (len(children) > 0 and children[0].hasAttribute('Name')) else 0
                w_u8(flag)
                for c in children:
                    if flag == 1:
                        w_u8(5)
                        w_bytes(strings[c.getAttribute('Name')])
                    w_property(c)
            elif ptype == 11:
                children = [c for c in node.childNodes if c.nodeType == c.ELEMENT_NODE]
                w_u32(len(children))
                for c in children:
                    w_property(c)
            elif ptype == 13: w_bytes(bytes.fromhex(node.getAttribute('Value')))
            elif ptype == 15: w_bytes(strings[node.getAttribute('Value')])
            elif ptype == 255: w_u32(int(node.getAttribute('Value')))

        def w_object(node):
            w_u8(1)
            w_bytes(strings[node.getAttribute('Class')])
            children = [c for c in node.childNodes if c.nodeType == c.ELEMENT_NODE]
            w_u32(len(children))
            for c in children:
                w_bytes(strings[c.getAttribute('Name')])
                w_property(c)

        w_u32(len(string_list))
        total_len = sum(8 + 4 + len(s.encode('utf-8')) for s in string_list)
        w_u32(total_len)
        
        for s in string_list:
            b = s.encode('utf-8')
            w_bytes(strings[s])
            w_u32(len(b))
            w_bytes(b)

        w_object(doc.documentElement)

        out = bytearray(b'BOD\x01\x00\x00\x00\x00\x00\x00')
        out.extend(data)
        
        with open(out_path, 'wb') as f:
            f.write(out)
            
        return True
    except Exception as e:
        print(f"BOD compilation failed for {xml_path}: {e}")
        return False

# =========================================================================
# STANDARD DCM PARSER
# =========================================================================

def _can_read(buf, off, size): return (off + size) <= len(buf)
def _r_u8 (buf, off): return struct.unpack_from("<B", buf, off)[0]
def _r_u16(buf, off): return struct.unpack_from("<H", buf, off)[0]
def _r_u32(buf, off): return struct.unpack_from("<I", buf, off)[0]
def _r_f32(buf, off): return struct.unpack_from("<f", buf, off)[0]
def bbox_minmax(verts):
    if not verts: return (0,0,0, 0,0,0)
    xs, ys, zs = zip(*verts)
    return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs))

def append_sm1_shader():
    shader_name = "sm1 shader by violet"
    if shader_name in bpy.data.node_groups: return bpy.data.node_groups[shader_name]
    addon_dir = os.path.dirname(os.path.realpath(__file__))
    blend_path = os.path.join(addon_dir, "sm1 shader by violet.blend")
    if not os.path.exists(blend_path): return None
    try:
        with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
            if shader_name in data_from.node_groups: data_to.node_groups = [shader_name]
        if data_to.node_groups: return data_to.node_groups[0]
    except: pass
    return None

def load_texture(directory, tex_name):
    for ext in ['.dds', '.png', '.tga', '.DDS', '.PNG', '.TGA']:
        p = os.path.join(directory, tex_name + ext)
        if os.path.exists(p):
            img = bpy.data.images.get(tex_name + ext)
            if not img: img = bpy.data.images.load(p)
            return img
    return None

def unwrap(p): 
    return p[1] if type(p) is tuple else p

class IMPORT_OT_space_marine_dcm(bpy.types.Operator, ImportHelper):
    bl_idname    = "import_scene.space_marine_dcm"
    bl_label     = "Import Space Marine DCM"
    filename_ext = ".dcm"
    filter_glob: StringProperty(default="*.dcm", options={'HIDDEN'})
    use_custom_shader: BoolProperty(name="Append Custom Shader", default=True)
    import_skeleton: BoolProperty(name="Import Armature", default=True)
    global_scale: FloatProperty(name="Scale", default=1.0, min=0.001, max=1000.0)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Import Options", icon='IMPORT')
        box.prop(self, "global_scale")
        box.prop(self, "import_skeleton")
        box.prop(self, "use_custom_shader")

    def execute(self, context):
        return import_dcm(self.filepath, context, self.use_custom_shader, self.import_skeleton, self.global_scale)

def import_dcm(path, context, use_custom_shader=True, import_skeleton=True, global_scale=1.0):
    raw = open(path, "rb").read()
    buf = memoryview(raw)
    off = 0
    if not _can_read(buf, off, 12): return {'CANCELLED'}
    
    header_size = _r_u32(buf, off); off += 4
    data_size   = _r_u32(buf, off); off += 4
    mesh_count  = _r_u32(buf, off); off += 4
    base = header_size

    custom_shader_tree = append_sm1_shader() if use_custom_shader else None
    
    directory = os.path.dirname(path)
    file_base = os.path.splitext(os.path.basename(path))[0]
    
    manifest_path = os.path.join(directory, f"{file_base}.object-manifest")
    o3d_path = os.path.join(directory, f"{file_base}.O3d")
    
    mat_names = []
    bmat_textures = {}
    visual_names = {}
    skeleton_name = f"{file_base}_Rig"
    
    def scan_for_materials(node):
        if type(node) is dict:
            cls = node.get('Class', '')
            props = node.get('Properties', {})
            
            if cls == 'O3d':
                obj_name = unwrap(props.get('Object', ''))
                mesh_name = unwrap(props.get('Mesh', ''))
                
                if (type(obj_name) is str and obj_name.lower() == file_base.lower()) or \
                   (type(mesh_name) is str and mesh_name.lower() == file_base.lower()):
                    if 'Materials' in props and type(props['Materials']) is list:
                        for m in props['Materials']:
                            val = unwrap(m)
                            if type(val) is str and val not in mat_names:
                                mat_names.append(val)
            
            for k, v in node.items():
                scan_for_materials(v)
        elif type(node) is list:
            for item in node:
                scan_for_materials(unwrap(item))
                
    def fallback_materials(node):
        if type(node) is dict:
            props = node.get('Properties', {})
            if 'Materials' in props and type(props['Materials']) is list:
                for m in props['Materials']:
                    val = unwrap(m)
                    if type(val) is str and val not in mat_names:
                        mat_names.append(val)
                return True
            for k, v in node.items():
                if fallback_materials(v): return True
        elif type(node) is list:
            for item in node:
                if fallback_materials(unwrap(item)): return True
        return False
                
    def scan_for_visuals(node):
        if type(node) is dict:
            cls = node.get('Class', '')
            props = node.get('Properties', {})
            
            if cls in ('SkinMeshVisual', 'StaticMeshVisual', 'MeshVisual', 'StaticMeshBlock'):
                m_id = unwrap(props.get('MeshID'))
                r_node = unwrap(props.get('RefNode'))
                if m_id is not None and r_node:
                    visual_names[m_id] = r_node
                    
            if cls == 'Skeleton3D':
                s_name = unwrap(props.get('Name'))
                if type(s_name) is str:
                    nonlocal skeleton_name
                    skeleton_name = s_name + "_Rig"
                    
            for k, v in node.items():
                scan_for_visuals(v)
        elif type(node) is list:
            for item in node:
                scan_for_visuals(unwrap(item))

    if os.path.exists(manifest_path):
        manifest_bod = NativeBODParser(manifest_path, dump_xml=True)
        if manifest_bod.valid:
            scan_for_materials(manifest_bod.root)
            if not mat_names:
                fallback_materials(manifest_bod.root)
            
    if os.path.exists(o3d_path):
        o3d_bod = NativeBODParser(o3d_path, dump_xml=True)
        if o3d_bod.valid:
            scan_for_materials(o3d_bod.root)
            if not mat_names:
                fallback_materials(o3d_bod.root)
            scan_for_visuals(o3d_bod.root)
                        
    for m_str in mat_names:
        bmat_path = os.path.join(directory, f"{m_str}.bmat")
        if os.path.exists(bmat_path):
            bmat_bod = NativeBODParser(bmat_path, dump_xml=True)
            if bmat_bod.valid:
                tex_maps = {}
                params = unwrap(bmat_bod.root['Properties'].get('Parameters', []))
                for p in params:
                    p = unwrap(p)
                    if type(p) is dict and p.get('Class') in ('TextureParameter', 'Vector4Parameter', 'Texture'):
                        p_name = unwrap(p['Properties'].get('Name'))
                        p_val = unwrap(p['Properties'].get('Value'))
                        if type(p_name) is str and isinstance(p_val, str): 
                            tex_maps[p_name] = p_val
                bmat_textures[m_str] = tex_maps

    for mi in range(mesh_count):
        if not _can_read(buf, off, 1): break
        flag = _r_u8(buf, off); off += 1
        is_skinned = (flag == 1)

        bones, inv_matrices, bone_ids = [], [], []
        if is_skinned:
            nv    = _r_u32(buf, off); off += 4
            _     = _r_u32(buf, off); off += 4
            ni    = _r_u32(buf, off); off += 4
            idx_o = _r_u32(buf, off); off += 4
            ns    = _r_u32(buf, off); off += 4
            nb    = _r_u32(buf, off); off += 4
            off  += 6*4 
            s0    = _r_u32(buf, off)
            s1    = _r_u32(buf, off+4)
            s2    = _r_u32(buf, off+8)
            off  += 12
            
            stride_v = 32
            stride_n = 28
            u_block  = 20
            
            for _ in range(nb):
                off += 1
                nl = _r_u16(buf, off); off += 2
                name = buf[off:off+nl].tobytes().decode("utf-8","ignore")
                off += nl
                mat = struct.unpack_from("<16f", buf, off); off += 16*4
                b_id = _r_u32(buf, off); off += 4
                
                bones.append(name)
                inv_matrices.extend(mat) 
                bone_ids.append(b_id)
        else:
            off += 1
            nv    = _r_u32(buf, off); off += 4
            off  += 4 
            ni    = _r_u32(buf, off); off += 4
            idx_o = _r_u32(buf, off); off += 4
            off  += 4
            ns    = _r_u32(buf, off); off += 4
            off  += 6*4
            s0    = _r_u32(buf, off)
            s1    = _r_u32(buf, off+4)
            s2    = 0
            off  += 8
            
            stride_v = 12
            stride_n = 48
            u_block  = 0

        submeshes = []
        for sub_index in range(ns):
            off += 1
            nl = _r_u16(buf, off); off += 2
            raw_name = buf[off:off+nl].tobytes().decode("utf-8","ignore")
            off += nl
            
            sub_unk_flag = _r_u32(buf, off); off += 4
            mat_idx      = _r_u32(buf, off); off += 4
            
            vc      = _r_u32(buf, off); off += 4
            vo      = _r_u32(buf, off); off += 4
            ic      = _r_u32(buf, off); off += 4
            io      = _r_u32(buf, off); off += 4
            sb      = _r_u32(buf, off); off += 4
            
            sub_bones = []
            for _ in range(sb):
                sub_bones.append(_r_u32(buf, off))
                off += 4
                
            hkx_offset = 0
            hkx_size = 0
            if flag == 2 and _can_read(buf, off, 8):
                hkx_offset = _r_u32(buf, off); off += 4
                hkx_size   = _r_u32(buf, off); off += 4
                
            submeshes.append({
                "sub_index": sub_index,
                "raw_name": raw_name,
                "sub_unk_flag": sub_unk_flag,
                "mat_idx": mat_idx,
                "vcount": vc, "icount": ic,
                "voff": vo, "ioff": io,
                "sub_bones": sub_bones,
                "hkx_offset": hkx_offset,
                "hkx_size": hkx_size
            })

        for sub in submeshes:
            raw_name = sub["raw_name"]
            mat_idx = sub["mat_idx"]
            sub_unk_flag = sub["sub_unk_flag"]
            sub_index = sub["sub_index"]
            
            mat_name = mat_names[mat_idx] if mat_idx < len(mat_names) else f"{file_base}_mat_{mat_idx}"
            vis_name = visual_names.get(mi, f"{file_base}_{mi}")
            
            if len(submeshes) > 1:
                obj_name = f"{vis_name}_{mat_name}_{sub_index}"
            else:
                obj_name = vis_name

            vc, ic = sub["vcount"], sub["icount"]
            vo, io = sub["voff"], sub["ioff"]
            sub_bones = sub["sub_bones"]

            base_v = base + s0 + vo * stride_v
            base_n = base + s1 + vo * stride_n
            base_u = (base + s2 + vo * u_block) if is_skinned else None
            base_i = base + idx_o + io * 2

            idxs = [_r_u16(buf, base_i + i * 2) for i in range(ic)]
            max_idx = max(idxs) if idxs else 0
            safe_vc = max(vc, max_idx + 1)

            vertices = []
            for idx in range(safe_vc):
                p = base_v + idx * stride_v
                if _can_read(buf, p, 12):
                    x = _sf(_r_f32(buf, p+0))
                    y = _sf(_r_f32(buf, p+4))
                    z = _sf(_r_f32(buf, p+8))
                    pos = (x * global_scale, y * global_scale, -z * global_scale)
                    vertices.append(pos)
                else:
                    vertices.append((0, 0, 0)) 

            faces = []
            seen_faces = set()
            for tri in range(0, len(idxs)-2, 3):
                i0, i1, i2 = idxs[tri], idxs[tri+1], idxs[tri+2]
                if i0 == i1 or i1 == i2 or i0 == i2: continue
                face_tuple = tuple(sorted((i0, i1, i2)))
                if face_tuple in seen_faces: continue
                seen_faces.add(face_tuple)
                faces.append((i0, i1, i2))

            mesh = bpy.data.meshes.new(obj_name)
            mesh.from_pydata(vertices, [], faces)
            mesh.update()
            for poly in mesh.polygons: poly.use_smooth = True

            num_loops = len(mesh.loops)
            uv_data = [0.0] * (num_loops * 2)
            uv1_data = [0.0] * (num_loops * 2)
            col_data = [1.0] * (num_loops * 4)

            for poly in mesh.polygons:
                for li in poly.loop_indices:
                    idx = mesh.loops[li].vertex_index
                    
                    q = base_n + idx * stride_n
                    if is_skinned:
                        r = base_u + idx * u_block
                        if _can_read(buf, r, 20):
                            u0 = _sf(_r_f32(buf, r+0))
                            v0 = 1.0 - _sf(_r_f32(buf, r+4))
                            u1 = _sf(_r_f32(buf, r+8))
                            v1 = 1.0 - _sf(_r_f32(buf, r+12))
                            c0 = _r_u8(buf, r+16)
                            c1 = _r_u8(buf, r+17)
                            c2 = _r_u8(buf, r+18)
                            c3 = _r_u8(buf, r+19)
                        else:
                            u0, v0, u1, v1 = 0.0, 0.0, 0.0, 0.0
                            c0, c1, c2, c3 = 255, 255, 255, 255
                    else:
                        if _can_read(buf, q+28, 20):
                            u0 = _sf(_r_f32(buf, q+28))
                            v0 = 1.0 - _sf(_r_f32(buf, q+32))
                            u1 = _sf(_r_f32(buf, q+36))
                            v1 = 1.0 - _sf(_r_f32(buf, q+40))
                            c0 = _r_u8(buf, q+44)
                            c1 = _r_u8(buf, q+45)
                            c2 = _r_u8(buf, q+46)
                            c3 = _r_u8(buf, q+47)
                        else:
                            u0, v0, u1, v1 = 0.0, 0.0, 0.0, 0.0
                            c0, c1, c2, c3 = 255, 255, 255, 255
                            
                    uv_data[li*2] = u0
                    uv_data[li*2+1] = v0
                    uv1_data[li*2] = u1
                    uv1_data[li*2+1] = v1
                    
                    col_data[li*4] = c0 / 255.0
                    col_data[li*4+1] = c1 / 255.0
                    col_data[li*4+2] = c2 / 255.0
                    col_data[li*4+3] = c3 / 255.0

            uv_map = mesh.uv_layers.new(name="UVMap")
            if uv_map: uv_map.data.foreach_set("uv", uv_data)
            
            uv1_map = mesh.uv_layers.new(name="UV1Map")
            if uv1_map: uv1_map.data.foreach_set("uv", uv1_data)
            
            if hasattr(mesh, "color_attributes"):
                color_attr = mesh.color_attributes.new(name="VertexColor", type='BYTE_COLOR', domain='CORNER')
                if color_attr: color_attr.data.foreach_set("color", col_data)
            else:
                color_attr = mesh.attributes.new(name="VertexColor", type='BYTE_COLOR', domain='CORNER')
                if color_attr: color_attr.data.foreach_set("color", col_data)

            mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(name=mat_name)
            if custom_shader_tree:
                mat.use_nodes = True
                nodes = mat.node_tree.nodes
                links = mat.node_tree.links
                for n in list(nodes):
                    if n.type == 'BSDF_PRINCIPLED': nodes.remove(n)
                
                out_node = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
                if not out_node:
                    out_node = nodes.new(type='ShaderNodeOutputMaterial')
                    out_node.location = (300, 0)
                
                group_node = next((n for n in nodes if n.type == 'GROUP' and n.node_tree == custom_shader_tree), None)
                if not group_node:
                    group_node = nodes.new(type='ShaderNodeGroup')
                    group_node.node_tree = custom_shader_tree
                    group_node.location = (0, 0)
                    group_node.name = "sm1 shader by violet"
                    group_node.label = "sm1 shader by violet"
                    
                if group_node.outputs and out_node.inputs:
                    links.new(group_node.outputs[0], out_node.inputs['Surface'])

                if mat_name in bmat_textures:
                    tex_dict = bmat_textures[mat_name]
                    
                    x_offset = -600
                    y_offset = 200
                    assigned_sockets = set()
                    
                    for param_key, tex_name in tex_dict.items():
                        if isinstance(tex_name, str) and tex_name:
                            t_lower = tex_name.lower().strip()
                            p_lower = param_key.lower().strip()
                            
                            if t_lower.endswith('_ref') or '_ref' in t_lower:
                                continue
                                
                            img = load_texture(directory, tex_name)
                            if img:
                                tex_node = nodes.new(type='ShaderNodeTexImage')
                                tex_node.image = img
                                tex_node.location = (x_offset, y_offset)
                                y_offset -= 280
                                
                                matched_socket = None
                                
                                if t_lower.endswith('_dif') or 'diff' in p_lower:
                                    matched_socket = 'diff'
                                elif t_lower.endswith('_nrm') or 'nrm' in p_lower:
                                    matched_socket = 'nrm'
                                elif t_lower.endswith('_lp') or 'lp' in p_lower:
                                    matched_socket = 'lp'
                                elif t_lower.endswith('_spc') or t_lower.endswith('_sp') or 'spec' in p_lower or 'spc' in p_lower:
                                    matched_socket = 'spc'

                                if not matched_socket:
                                    for socket_name in ['diff', 'nrm', 'lp', 'spc']:
                                        if socket_name not in assigned_sockets:
                                            matched_socket = socket_name
                                            break

                                actual_socket_name = None
                                if matched_socket:
                                    for ipt in group_node.inputs:
                                        if ipt.name.strip().lower() == matched_socket.lower():
                                            actual_socket_name = ipt.name
                                            break

                                if actual_socket_name and actual_socket_name not in assigned_sockets:
                                    links.new(tex_node.outputs['Color'], group_node.inputs[actual_socket_name])
                                    assigned_sockets.add(actual_socket_name)

            mesh.materials.append(mat)
            obj = bpy.data.objects.new(obj_name, mesh)
            
            obj["sm_raw_name"] = raw_name
            obj["sm_mesh_id"] = mi
            obj["sm_node_idx"] = sub_unk_flag
            obj["sm_mat_idx"] = mat_idx
            
            hkx_data = ""
            if sub["hkx_size"] > 0:
                abs_off = base + sub["hkx_offset"]
                if _can_read(buf, abs_off, sub["hkx_size"]):
                    hkx_bytes = buf[abs_off : abs_off + sub["hkx_size"]].tobytes()
                    hkx_data = hkx_bytes.hex()
                    
            if hkx_data:
                text_name = f"{obj_name}_hkx_data"
                if text_name not in bpy.data.texts:
                    txt = bpy.data.texts.new(text_name)
                else:
                    txt = bpy.data.texts[text_name]
                txt.clear()
                txt.write(hkx_data)
                obj["sm_hkx_text"] = text_name

            context.collection.objects.link(obj)

            if is_skinned:
                obj["dcm_bones"] = bones
                obj["dcm_inv_mats"] = inv_matrices
                obj["dcm_bone_ids"] = bone_ids
                
                vgs = {bname: obj.vertex_groups.new(name=bname) for bname in bones}
                for idx in range(safe_vc):
                    p = base_v + idx * stride_v
                    if _can_read(buf, p+12, 16) and _can_read(buf, p+28, 4):
                        w = struct.unpack_from("<4f", buf, p+12)
                        local_ind = struct.unpack_from("<4B", buf, p+28)
                        for weight, local_idx in zip(w, local_ind):
                            safe_weight = _sf(weight)
                            if safe_weight > 0.0:
                                global_bone_idx = sub_bones[local_idx] if local_idx < len(sub_bones) else 0
                                bname = bones[global_bone_idx] if global_bone_idx < len(bones) else "Bone"
                                vgs[bname].add([idx], safe_weight, 'REPLACE')
                        
                if import_skeleton:
                    arm_data = bpy.data.armatures.new(skeleton_name)
                    arm_obj = bpy.data.objects.new(skeleton_name, arm_data)
                    context.collection.objects.link(arm_obj)
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    arm_obj.select_set(True)
                    context.view_layer.objects.active = arm_obj
                    bpy.ops.object.mode_set(mode='EDIT')
                    
                    flip_z = mathutils.Matrix.Scale(-1.0, 4, (0, 0, 1))
                    for i, bname in enumerate(bones):
                        eb = arm_obj.data.edit_bones.new(bname)
                        im = inv_matrices[i*16 : (i+1)*16]
                        inv_matrix = mathutils.Matrix([im[0:4], im[4:8], im[8:12], im[12:16]])
                        inv_matrix.transpose()
                        try:
                            world_mat = flip_z @ inv_matrix.inverted() @ flip_z
                        except ValueError:
                            world_mat = mathutils.Matrix()
                            
                        eb.head = world_mat.translation * global_scale
                        eb.tail = eb.head + (world_mat.to_3x3() @ mathutils.Vector((0.0, 0.1 * global_scale, 0.0)))
                        eb.matrix = world_mat
                    bpy.ops.object.mode_set(mode='OBJECT')
                    mod = obj.modifiers.new(type='ARMATURE', name="Armature")
                    mod.object = arm_obj
                    obj.parent = arm_obj

    return {'FINISHED'}

class EXPORT_OT_space_marine_dcm(bpy.types.Operator, ExportHelper):
    bl_idname    = "export_scene.space_marine_dcm"
    bl_label     = "Export Space Marine DCM"
    filename_ext = ".dcm"
    filter_glob: StringProperty(default="*.dcm", options={'HIDDEN'})
    use_selection: BoolProperty(name="Selection Only", default=True)
    use_visible: BoolProperty(name="Visible Only", default=False)
    apply_transforms: BoolProperty(name="Apply Transform", default=True)
    global_scale: FloatProperty(name="Scale", default=1.0, min=0.001, max=1000.0)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Export Options", icon='EXPORT')
        box.prop(self, "use_selection")
        box.prop(self, "use_visible")
        box.prop(self, "apply_transforms")
        box.prop(self, "global_scale")

    def execute(self, context):
        return export_dcm(self.filepath, context, self.use_selection, self.use_visible, self.apply_transforms, self.global_scale)

def export_dcm(path, context, use_selection=True, use_visible=False, apply_transforms=True, global_scale=1.0):
    candidates = context.selected_objects if use_selection else context.scene.objects
    objects = [obj for obj in candidates if obj.type == 'MESH' and (not use_visible or obj.visible_get())]
    if not objects: return {'CANCELLED'}

    objects = sorted(objects, key=lambda o: o.get("sm_mesh_id", 9999))
    
    mesh_datas = []
    depsgraph = context.evaluated_depsgraph_get()

    for obj in objects:
        is_skinned = len(obj.vertex_groups) > 0
        vg_dict = {vg.index: vg.name for vg in obj.vertex_groups}
        
        dcm_bones = list(obj.get("dcm_bones", []))
        dcm_inv_mats = list(obj.get("dcm_inv_mats", []))
        dcm_bone_ids = list(obj.get("dcm_bone_ids", []))
        
        hkx_data = ""
        text_name = obj.get("sm_hkx_text", "")
        if text_name and text_name in bpy.data.texts:
            hkx_data = bpy.data.texts[text_name].as_string()
            
        if hkx_data:
            flag = 2
        elif is_skinned:
            flag = 1
        else:
            flag = 0

        if is_skinned and dcm_bones: bones = dcm_bones
        elif is_skinned: bones = list(vg_dict.values())
        else: bones = []
            
        bone_to_global_idx = {name: i for i, name in enumerate(bones)}

        if is_skinned:
            mesh = obj.to_mesh()
        else:
            obj_eval = obj.evaluated_get(depsgraph)
            mesh = obj_eval.to_mesh()
            if apply_transforms: mesh.transform(obj.matrix_world)
            
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.triangulate(bm, faces=bm.faces, quad_method='BEAUTY', ngon_method='BEAUTY')
        bm.to_mesh(mesh)
        bm.free()

        try:
            mesh.calc_normals_split()
        except AttributeError:
            pass
            
        try:
            mesh.calc_tangents()
        except RuntimeError:
            pass

        uv_layer0 = mesh.uv_layers.get("UVMap") or mesh.uv_layers.active
        uv_layer1 = mesh.uv_layers.get("UV1Map")
        
        color_layer = None
        if hasattr(mesh, "color_attributes"):
            color_layer = mesh.color_attributes.get("VertexColor") or mesh.color_attributes.active_color
        else:
            color_layer = mesh.attributes.get("VertexColor")
            
        num_loops = len(mesh.loops)
        
        uv0_flat = [0.0] * (num_loops * 2)
        if uv_layer0: uv_layer0.data.foreach_get("uv", uv0_flat)
        
        uv1_flat = [0.0] * (num_loops * 2)
        if uv_layer1: uv_layer1.data.foreach_get("uv", uv1_flat)
        
        col_flat = [1.0] * (num_loops * 4)
        if color_layer: color_layer.data.foreach_get("color", col_flat)
        
        sub_bones = []
        global_to_local_idx = {}
        
        nverts = len(mesh.vertices)
        
        v_pos = [(0,0,0)] * nverts
        v_weights = [(0.0,0.0,0.0,0.0)] * nverts
        v_local_indices = [(0,0,0,0)] * nverts
        v_num_bones = [1] * nverts

        for v in mesh.vertices:
            pos = (v.co.x / global_scale, v.co.y / global_scale, -v.co.z / global_scale)
            v_pos[v.index] = pos
            
            if is_skinned:
                w_data = []
                for g in v.groups:
                    if g.group in vg_dict and vg_dict[g.group] in bone_to_global_idx:
                        g_idx = bone_to_global_idx[vg_dict[g.group]]
                        if g_idx not in global_to_local_idx:
                            global_to_local_idx[g_idx] = len(sub_bones)
                            sub_bones.append(g_idx)
                        w_data.append((g.weight, global_to_local_idx[g_idx]))
                
                w_data.sort(reverse=True, key=lambda x: x[0])
                w_data = w_data[:4]
                
                total = sum(w for w, i in w_data)
                if total > 0: w_data = [(w/total, i) for w, i in w_data]
                else: w_data = [(1.0, 0)] if len(sub_bones) > 0 else [(0.0, 0)]
                    
                num_bones = sum(1 for w, i in w_data if w > 0)
                if num_bones == 0: num_bones = 1
                
                while len(w_data) < 4: w_data.append((0.0, 0))
                
                v_weights[v.index] = tuple(w for w, i in w_data)
                v_local_indices[v.index] = tuple(i for w, i in w_data)
                v_num_bones[v.index] = num_bones

        class VertInfo: pass
        vertlist = []
        idxlist = []
        unique_verts = {}

        for poly in mesh.polygons:
            for loop_idx in poly.loop_indices:
                v_idx = mesh.loops[loop_idx].vertex_index
                
                nor = (mesh.loops[loop_idx].normal.x, mesh.loops[loop_idx].normal.y, -mesh.loops[loop_idx].normal.z)
                tan = (mesh.loops[loop_idx].tangent[0], mesh.loops[loop_idx].tangent[1], -mesh.loops[loop_idx].tangent[2], mesh.loops[loop_idx].bitangent_sign)
                
                uv0 = (uv0_flat[loop_idx*2], 1.0 - uv0_flat[loop_idx*2+1]) if uv_layer0 else (0.0, 0.0)
                uv1 = (uv1_flat[loop_idx*2], 1.0 - uv1_flat[loop_idx*2+1]) if uv_layer1 else (0.0, 0.0)
                
                if color_layer:
                    r = col_flat[loop_idx*4]
                    g = col_flat[loop_idx*4+1]
                    b = col_flat[loop_idx*4+2]
                    a = col_flat[loop_idx*4+3]
                    col = (int(r*255), int(g*255), int(b*255), int(a*255))
                else:
                    col = (255, 255, 255, 255)

                sig = (v_idx, round(uv0[0], 5), round(uv0[1], 5), round(nor[0], 3), round(nor[1], 3), round(nor[2], 3))
                
                if sig not in unique_verts:
                    vi = VertInfo()
                    vi.pos = v_pos[v_idx]
                    vi.nor = nor
                    vi.tan = tan
                    vi.uv = uv0
                    vi.uv1 = uv1
                    vi.color = col
                    vi.weights = v_weights[v_idx]
                    vi.local_indices = v_local_indices[v_idx]
                    vi.num_bones = v_num_bones[v_idx]
                    
                    unique_verts[sig] = len(vertlist)
                    vertlist.append(vi)
                
                idxlist.append(unique_verts[sig])

        mat_name = mesh.materials[0].name if mesh.materials else "default"
        mat_name = mat_name.split(".")[0]
        raw_name = obj.get("sm_raw_name", obj.name)

        mesh_datas.append({
            "name": obj.name, "is_skinned": is_skinned,
            "flag": flag, "hkx_data": hkx_data,
            "bones": bones, "sub_bones": sub_bones,
            "nverts": len(vertlist), "nindices": len(idxlist), 
            "vertlist": vertlist, "idxlist": idxlist,
            "orig_bones": dcm_bones, "orig_mats": dcm_inv_mats, 
            "orig_ids": dcm_bone_ids, "obj": obj, "mat_name": mat_name,
            "raw_name": raw_name,
            "node_idx": obj.get("sm_node_idx", 1), 
            "mat_idx": obj.get("sm_mat_idx", 0)  
        })
        if not is_skinned: obj_eval.to_mesh_clear()

    header_size, data_cursor = 12, 0
    for d in mesh_datas:
        if d["flag"] == 1:
            header_size += 61 
            for bname in d["bones"]: header_size += 71 + len(bname.encode('utf-8'))
        else: header_size += 58 
            
        header_size += 31 + len(d["raw_name"].encode('utf-8')) 
        
        if d["flag"] == 1: 
            header_size += 4 * len(d["sub_bones"])
        elif d["flag"] == 2:
            header_size += 8

        idx_size = d["nindices"] * 2
        d["idx_off"] = data_cursor
        d["v0_off"] = d["idx_off"] + idx_size
        
        if d["flag"] == 1:
            d["v1_off"] = d["v0_off"] + d["nverts"] * 32
            d["v2_off"] = d["v1_off"] + d["nverts"] * 28
            data_cursor += idx_size + d["nverts"] * (32 + 28 + 20) 
        else:
            d["v1_off"] = d["v0_off"] + d["nverts"] * 12
            d["v2_off"] = 0
            data_cursor += idx_size + d["nverts"] * (12 + 48)

        if d["flag"] == 2 and d["hkx_data"]:
            data_cursor += 4 
            d["hkx_off"] = data_cursor
            hkx_bytes = bytes.fromhex(d["hkx_data"])
            d["hkx_size"] = len(hkx_bytes)
            data_cursor += d["hkx_size"]

    header = bytearray()
    header += struct.pack("<I", header_size)
    header += struct.pack("<I", data_cursor)
    header += struct.pack("<I", len(mesh_datas))

    for d in mesh_datas:
        header += struct.pack("<B", d["flag"])
        if d["flag"] == 1:
            header += struct.pack("<I", d["nverts"])
            header += struct.pack("<I", 40)
            header += struct.pack("<I", d["nindices"])
            header += struct.pack("<I", d["idx_off"])
            header += struct.pack("<I", 1) 
            header += struct.pack("<I", len(d["bones"]))
            header += struct.pack("<6f", *bbox_minmax([v.pos for v in d["vertlist"]]))
            header += struct.pack("<I", d["v0_off"])
            header += struct.pack("<I", d["v1_off"])
            header += struct.pack("<I", d["v2_off"])
            
            orig_bones_clean = [b.lower().split(".")[0] for b in (d["orig_bones"] or [])]
            for b_idx, bname in enumerate(d["bones"]):
                header += struct.pack("<B", 255)
                bbytes = bname.encode('utf-8')
                header += struct.pack("<H", len(bbytes))
                header += bbytes
                
                clean_name = bname.lower().split(".")[0]
                orig_mats = d["orig_mats"]
                
                if d["orig_bones"] and clean_name in orig_bones_clean and len(orig_mats) == len(d["orig_bones"]) * 16:
                    o_idx = orig_bones_clean.index(clean_name)
                    header += struct.pack("<16f", *orig_mats[o_idx*16 : (o_idx+1)*16])
                    header += struct.pack("<I", d["orig_ids"][o_idx])
                else:
                    header += struct.pack("<16f", 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
                    header += struct.pack("<I", b_idx)
        else:
            header += struct.pack("<B", 0)
            header += struct.pack("<I", d["nverts"])
            header += struct.pack("<I", 60) 
            header += struct.pack("<I", d["nindices"])
            header += struct.pack("<I", d["idx_off"])
            header += struct.pack("<I", 2)
            header += struct.pack("<I", 1) 
            header += struct.pack("<6f", *bbox_minmax([v.pos for v in d["vertlist"]]))
            header += struct.pack("<I", d["v0_off"])
            header += struct.pack("<I", d["v1_off"])

        header += struct.pack("<b", -1)
        name_bytes = d["raw_name"].encode('utf-8')
        header += struct.pack("<H", len(name_bytes))
        header += name_bytes
        
        header += struct.pack("<I", d["node_idx"])
        header += struct.pack("<I", d["mat_idx"])
        
        header += struct.pack("<I", d["nverts"])
        header += struct.pack("<I", 0)
        header += struct.pack("<I", d["nindices"])
        header += struct.pack("<I", 0)
        
        if d["flag"] == 1:
            header += struct.pack("<I", len(d["sub_bones"]))
            for b in d["sub_bones"]: header += struct.pack("<I", b)
        else:
            header += struct.pack("<I", 0)
            
        if d["flag"] == 2:
            header += struct.pack("<I", d["hkx_off"])
            header += struct.pack("<I", d["hkx_size"])

    data = bytearray()
    for d in mesh_datas:
        for i in d["idxlist"]: data += struct.pack("<H", i)
        if d["flag"] == 1:
            for v in d["vertlist"]:
                data += struct.pack("<fff", *v.pos)
                data += struct.pack("<ffff", *v.weights)
                data += struct.pack("<4B", *v.local_indices)
            for v in d["vertlist"]:
                data += struct.pack("<fff", *v.nor)
                data += struct.pack("<ffff", *v.tan) 
            for v in d["vertlist"]:
                data += struct.pack("<ff", *v.uv)
                data += struct.pack("<ff", *v.uv1)
                data += struct.pack("<4B", *v.color) 
            for v in d["vertlist"]:
                data += struct.pack("<I", v.num_bones)
                data += struct.pack("<fff", *v.pos)
                data += struct.pack("<fff", *v.nor)
                data += struct.pack("<ffff", *v.tan) 
            for v in d["vertlist"]:
                data += struct.pack("<ffff", *v.weights)
            for v in d["vertlist"]:
                data += struct.pack("<4B", *v.local_indices)
        else:
            for v in d["vertlist"]: data += struct.pack("<fff", *v.pos)
            for v in d["vertlist"]:
                data += struct.pack("<fff", *v.nor)
                data += struct.pack("<ffff", *v.tan) 
                data += struct.pack("<ff", *v.uv)
                data += struct.pack("<ff", *v.uv1)
                data += struct.pack("<4B", *v.color) 
                
        if d["flag"] == 2 and d["hkx_data"]:
            data += struct.pack("<I", 0)
            data += bytes.fromhex(d["hkx_data"])

    with open(path, "wb") as f:
        f.write(header)
        f.write(data)

    print(f"Exported DCM with {len(mesh_datas)} meshes: '{path}'")
    
    xml_path = path.replace('.dcm', '.O3d.xml')
    if os.path.exists(xml_path):
        compile_bod_from_xml(xml_path, path.replace('.dcm', '.O3d'))
            
    manifest_xml = path.replace('.dcm', '.object-manifest.xml')
    if os.path.exists(manifest_xml):
        compile_bod_from_xml(manifest_xml, path.replace('.dcm', '.object-manifest'))

    return {'FINISHED'}

def menu_import(self, _): self.layout.operator(IMPORT_OT_space_marine_dcm.bl_idname, text="Space Marine DCM (.dcm)")
def menu_export(self, _): self.layout.operator(EXPORT_OT_space_marine_dcm.bl_idname, text="Space Marine DCM (.dcm)")
def register():
    bpy.utils.register_class(IMPORT_OT_space_marine_dcm)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    bpy.utils.register_class(EXPORT_OT_space_marine_dcm)
    bpy.types.TOPBAR_MT_file_export.append(menu_export)
def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    bpy.utils.unregister_class(IMPORT_OT_space_marine_dcm)
    bpy.types.TOPBAR_MT_file_export.remove(menu_export)
    bpy.utils.unregister_class(EXPORT_OT_space_marine_dcm)

if __name__ == "__main__": register()