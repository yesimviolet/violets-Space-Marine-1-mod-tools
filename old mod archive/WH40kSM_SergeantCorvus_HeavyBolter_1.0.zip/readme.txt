Warhammer 40,000 Space Marine - Sergeant Corvus Heavy Bolter Mod v1.0
---------------------------------------------------------------------
A mini mod that gives Sergeant Corvus a Heavy Bolter in place of his regular Bolter. This should make the bridge fight a little more interesting. I gave Corvus a bad aim from long range, so he shouldn't be taking much kills from the player. Can be installed after or without any of my armor mods. For Warhammer 40,000 Space Marine version 1.0.156.0 or higher, with or without any DLC.


Install
-------
If you have any of my armor mods, make sure you install this after my armor mods. Best to backup your existing mods, just in case. Copy the 'preview' folder to your Space Marine directory found in your Steam folder:

C:\Program Files (x86)\Steam\steamapps\common\warhammer 40,000 space marine


Uninstall
---------
Remove the following files and folders from your 'preview' folder found in your Space Marine directory:

preview\art\race_marine\characters\spacemarine\backpack\sm_hbolter_backpack_001
preview\art\race_marine\characters\spacemarine\weaponranged_mp\heavybolter_mp_basic
preview\sim\attributes\instances\ebps\race_marine\units\ai_blood_raven_capt.attr_pc
preview\sim\attributes\instances\wargear\wargear\multiplayer\race_marine\weapons\sm_mp_exotic_heavy_bolter.attr_pc


Compatibility
-------------
This mod will make changes to Blood Ravens Sergeant Corvus and the MP heavy bolter. Any other mods that makes use of the files located above in under the Uninstall section will not be compatible with this mod.


Credits
-------
All models are created and/or edited by cerberos008
Original game models created by Relic Entertainment

I hardly ever check my mail, so permission for use of this mod will be granted automatically as long as credit is given for the original owners of the materials used. Please link back to this thread:

http://forums.relicnews.com/showthread.php?265090-SM-Keeper-of-the-Armory-Mod-1.0&p=1045338281#post1045338281

and also send me a little notice of your mod so that I know your mod exists. 