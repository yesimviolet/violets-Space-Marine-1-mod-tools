Warhammer 40,000 Space Marine - Flamer Mod v1.1
-----------------------------------------------
Replaces the Meltagun with the Flamer. New model with bits and pieces of the bolter stuck on to it. Has a working flame effect, but it doesn't look that good when looking at it from the side. For Warhammer 40,000 Space Marine version 1.0.156.0 or higher, with or without any DLC.

Update 1.1: Fixed file directory for melta.attr_pc

Install
-------
Copy the 'preview' folder to your Space Marine directory found in your Steam folder:

C:\Program Files (x86)\Steam\steamapps\common\warhammer 40,000 space marine


Uninstall
---------
Remove the following files and folders from your 'preview' folder found in your Space Marine directory:

preview\art\race_marine\characters\spacemarine\weaponranged\meltagun\
preview\sim\attributes\instances\wargear\wargear\race_marine\weapons\2hand_ranged\rifle\melta.attr_pc


Compatibility
-------------
This mod completely replaces the Meltagun's model and attr_pc file. If you have any existing mod that makes use of these files, then there will be a conflict.


Credits
-------
All models are created and/or edited by cerberos008
Original game models created by Relic Entertainment

I hardly ever check my mail, so permission for use of this mod will be granted automatically as long as credit is given for the original owners of the materials used. Please link back to this thread:

http://forums.relicnews.com/showthread.php?265090-SM-Keeper-of-the-Armory-Mod-1.0&p=1045338281#post1045338281

and also send me a little notice of your mod so that I know your mod exists. 