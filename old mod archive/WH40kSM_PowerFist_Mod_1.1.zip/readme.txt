Warhammer 40,000 Space Marine - Power Fist Mod v1.1
---------------------------------------------------
Replaces the Thunderhammer with a fully functional Power Fist. This Power Fist was made completely from scratch, but was modelled after the Dawn of War II's Power Fist design. For Warhammer 40,000 Space Marine version 1.0.156.0 or higher, with or without any DLC.

v1.1
----
Replaced model with a higher poly mesh.


Install
-------
Copy the 'preview' folder to your Space Marine directory found in your Steam folder:

C:\Program Files (x86)\Steam\steamapps\common\warhammer 40,000 space marine


Uninstall
---------
Remove the following files and folders from your 'preview' folder found in your Space Marine directory:

preview\art\race_marine\characters\spacemarine\armour_mp\sm_armour_mp_bloodravens\sm_armour_mp_bloodravens_armr\
preview\art\race_marine\characters\spacemarine\weaponmelee\thunderhammer_basic\
preview\sim\attributes\instances\wargear\wargear\race_marine\weapons\2hand_melee\thunderhammer_new.attr_pc


Compatibility
-------------
This mod replaces the 'MP Blood Ravens Right Arm (sm_armour_mp_bloodravens_armr)' and the 'Thunderhammer (thunderhammer_basic)' with the Power Fist model. If you have any mods that make use of these models, then there will be a conflict with this mod.


Credits
-------
All models are created and/or edited by cerberos008
Original game models created by Relic Entertainment

I hardly ever check my mail, so permission for use of this mod will be granted automatically as long as credit is given for the original owners of the materials used. Please link back to this thread:

http://forums.relicnews.com/showthread.php?265090-SM-Keeper-of-the-Armory-Mod-1.0&p=1045338281#post1045338281

and also send me a little notice of your mod so that I know your mod exists. 