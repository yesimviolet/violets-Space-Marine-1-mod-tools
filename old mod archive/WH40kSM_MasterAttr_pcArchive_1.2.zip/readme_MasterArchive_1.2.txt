Warhammer 40,000 Space Marine - Master Attr_pc Archive v1.2
-----------------------------------------------------------
This master archive holds all the attr_pc files for every Space Marine and Chaos Marine weapons and armors. Required for all of my mods to work properly. Apparently, certain un-modded weapons were not showing up in the game. This should fix that. For Warhammer 40,000 Space Marine version 1.0.156.0 or higher, with or without any DLC.

Update 1.1: Removed belt.attr_pc files that were causing unwanted loinclothes to show.
Update 1.2: Added attr_pc files for Imperial Guard over missing guard weapons.


Install
-------
Update 1.1: For those who have the old version, go into the following directory in your own preview folder and remove these files:

preview\sim\attributes\instances\wargear\wargear\race_marine\armour\powerarmour_basic_upres\belt.attr_pc
preview\sim\attributes\instances\wargear\wargear\race_marine\armour\powerarmour_basic_upres\belt_fe.attr_pc

If you already have any of my mods, just copy all the files from this master archive to your preview folder, but do not replace any of your existing files.

Otherwise, just copy the 'preview' folder to your Space Marine directory found in your Steam folder:

C:\Program Files (x86)\Steam\steamapps\common\warhammer 40,000 space marine

Then install any of my mods after that.


Credits
-------
All models are created and/or edited by cerberos008
Original game models created by Relic Entertainment

I hardly ever check my mail, so permission for use of this mod will be granted automatically as long as credit is given for the original owners of the materials used. Please link back to this thread:

http://forums.relicnews.com/showthread.php?265090-SM-Keeper-of-the-Armory-Mod-1.0&p=1045338281#post1045338281

and also send me a little notice of your mod so that I know your mod exists. 